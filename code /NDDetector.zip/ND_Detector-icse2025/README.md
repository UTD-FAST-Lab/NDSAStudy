# NDDetector

NDDetector (Non-determinism detector) is a flexible tool that can be used to detect non-deterministic behaviors in configurable static analysis on a variety of benchmarks.
NDDetector can be extended to use alternative analyses, but currently, it can run 
call graph analyses using WALA, SOOT, DOOP, OPAL, TAJS, PyCG, and Code2Flow, taint analysis on Android applications using FlowDroid, AmanDroid, and DroidSafe, as well as vulnerability detection on C programs using Infer.

<!-- _Note: NDDetector is built upon the foundation of ECSTATIC with extended features to analyze non-determinism results. ECSTATIC is a tool that is presented in an [ICSE 2023 paper](https://ieeexplore.ieee.org/abstract/document/10172552). We acknowledge and appreciate the work done by the developers of the original tool._ -->

# Experiments for Artifact Review
To maintain the anonymity of the submission, we have anonymized links that we use to access external tools and benchmarks. Therefore, the full experiments are not functional in this version of the artifact. We plan to make a submission to the artifact evaluation track upon acceptance of our paper with all the experiments working.

For this version of the artifact, we have made the analysis tool FlowDroid available, as well as the benchmark 'icse25-ezbench', which comprises four programs from the DroidBench 3.0 benchmark. **After following the instructions in [INSTALL.md](INSTALL.md)**, you can run this experiment with the following command:

`dispatcher -t flowdroid -b icse25-ezbench --tasks taint -i 5`

where `-i 5` can be configured to the number of iterations you wish to run. This will create a `results` folder. Details on how to read the contents of this folder are below.

## How to Read NDDetector Output

By default, NDDetector creates a *results* folder for its results, but the location of the results can be controlled with the `--results-location` option.

We explain the results of NDDetector through the example above, where we run FlowDroid on the `icse25-ezbench` benchmark.

```commandline
results
|- flowdroid
|  |- icse25-ezbench
|  |  |- iteration0
|  |  |  |- configurations
|  |  |  |  |- 1e9c00f5704518e138859b037784c841
|  |  |  |  |- 3d42058705611ed0e83612b6dff38a35
|  |  |  |  |- ...
|  |  |  |- .1e9c00f5704518e138859b037784c841_JavaThread2-debug.apk.raw.log
|  |  |  |- .1e9c00f5704518e138859b037784c841_JavaThread2-debug.apk.raw.time
|  |  |  |- .3d42058705611ed0e83612b6dff38a35_JavaThread2-debug.apk.raw.log
|  |  |  |- .3d42058705611ed0e83612b6dff38a35_JavaThread2-debug.apk.raw.time
|  |  |  |- ...
|  |  |  |- 1e9c00f5704518e138859b037784c841_JavaThread2-debug.apk.raw
|  |  |  |- 3d42058705611ed0e83612b6dff38a35_JavaThread2-debug.apk.raw
|  |  |  |- ...
|- non-determinism
|  |- flowdroid
|  |  |- icse25-ezbench
|  |  |  |- 7b5480bdb06b2ff39ebfb2bcedd2f657_JavaThread2.apk.raw
|  |  |  |  |- run-0
|  |  |  |  |- run-1
|  |  |  |  |- ...
```

The results of each iteration are stored in their respective folders. For each configuration-program pair, three files are generated, each with a different extension: `.raw`, `.raw.log`, and `.raw.time`. These files correspond to the results produced by the tool, which will be processed by the *ToolReader* implementation, the log for each experiment, and the execution time for each experiment, respectively.

Configurations in the results are represented as hash values. You can see what configuration a hash value represents by looking in the configuration folder. In this example, configuration 1e9c00f5704518e138859b037784c841 corresponds to the configuration `--aplength 10 --cgalgo RTA --nothischainreduction --dataflowsolver CONTEXTFLOWSENSITIVE --aliasflowins --singlejoinpointabstraction --staticmode CONTEXTFLOWSENSITIVE --nostatic --codeelimination PROPAGATECONSTS --implicit ALL --callbackanalyzer FAST --maxcallbackspercomponent 1 --maxcallbacksdepth 1 --enablereflection --pathalgo CONTEXTSENSITIVE --taintwrapper NONE`

The results of non-determinism detection can be found in the `non-determinism` folder. This folder maintains all non-deterministic results across 5 iterations, each batch of results is stored under a folder named as `configration-hash_apk-name.apk.raw`.

In our example, one detected non-determinism is on `JavaThread2.apk` under configuration  `7b5480bdb06b2ff39ebfb2bcedd2f657`.

## Post-processing Results

We provide a post-processing script, [scripts/analysis/post_process.py](scripts/analysis/post_process.py). To execute this step, navigate to the `scripts/analysis` directory and run the following command:

```
python post_process.py --path <path-to-non_determinism-folder> <tool> <benchmark>
```

This command generates a CSV file in the `results/postprocess` folder, aggregating all results for the specified tool-benchmark pair. It also calculates the percentage of consistent results and the number of distinct results.

We run this script for every tool-benchmark pair and compile the results into `ICSE2025_AGGREGATE_DATA.csv`.

Additionally, we provide a Jupyter notebook, [scripts/notebooks/graphs.ipynb](scripts/notebooks/graphs.ipynb), to generate figures 3 and 4 for `RQ2.2`. This notebook requires `ICSE2025_AGGREGATE_DATA.csv` as input, containing all results from the CSVs generated by the `post_process.py` script. It is designed to work with the complete dataset, including non-determinism data from all eight tools discussed in the paper.

<!-- # Extending with New Tools
To add a new tool to NDDetector, you must take the following steps:
1. Create a new Dockerfile for your tool under `src/resources/tools/<tool_name>`.
The Dockerfile must create an image that inherits from NDDetector’s base image and builds the tool. See some of the existing Dockerfiles we have for examples.
2. Specify the configuration space in `src/resources/new_configurations/` as a csv file. 
3. Add a new class that inherits from [AbstractCommandLineToolRunner.py](src/ecstatic/runners/AbstractCommandLineToolRunners.py) 
in order to run the tool. Specifically, you must override the `try_run_job` method. If your tool is able to be run relatively simply
(i.e., only by setting command line options), then you might find it easier to 
extend [CommandLineToolRunner.py](src/ecstatic/runners/CommandLineToolRunner.py). See [SOOTRunner.py](src/ecstatic/runners/SOOTRunner.py) 
and [WALARunner.py](src/ecstatic/runners/WALARunner.py) for examples of classes that extend CommandLineToolRunner, and 
[DOOPRunner.py](src/ecstatic/runners/DOOPRunner.py) and [FlowDroidRunner.py](src/ecstatic/runners/FlowDroidRunner.py) for examples of more complex
runners that inherit from AbstractCommandLineToolRunner.py.
4. Add logic to [RunnerFactory.py](src/ecstatic/runners/RunnerFactory.py) to initialize your new runner given the 
name of the tool.
5. Add a new class that inherits from [AbstractRunner.py](src/ecstatic/readers/AbstractReader.py) to read the results of your tool.
The `import_file` method of this class accepts a file name, and returns an iterable of results.
In order to detect violations, it is important that equality be defined correctly between the results.
6. Add logic to [ReaderFactory.py](src/ecstatic/readers/ReaderFactory.py) that will return the appropriate reader given the task and tool name.

# Extending with New Benchmarks
Adding a new benchmark is relatively simple.
1. Add a new folder to [src/resources/benchmarks](src/resources/benchmarks), with the name of your benchmark.
2. In that folder, create a `build.sh` script that will pull the benchmark code, build it, and put it under `/benchmarks/<benchmark_name>` in the Docker container. Add an `index.json` file specifying the programs you want to run. The resolver for this file will automatically resolve paths so long as they are unique in the `/benchmarks` directory. -->
